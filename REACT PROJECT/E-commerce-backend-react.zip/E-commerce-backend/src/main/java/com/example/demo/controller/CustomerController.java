package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Customer;
import com.example.demo.service.CustomerService;


@RestController
@CrossOrigin(origins ="http://localhost:3000")
public class CustomerController {
	
	@Autowired
	CustomerService service;
	
	@PostMapping( value = "/saveCustomer" ,consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<Customer> print(@RequestBody Customer cust)
	{
		service.store(cust);
		return new ResponseEntity<Customer>(cust, HttpStatus.CREATED);
	}
	

	@GetMapping( value = "/Customers" ,produces = MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<List<Customer>> getStds()
	{
		List<Customer> list=service.getCustomer();
		return new ResponseEntity<List<Customer>>(list,HttpStatus.CREATED);
	}
	@PostMapping("/login")
    public Customer loginuser(@RequestBody Customer cust) throws Exception
    {
    String tempemail=cust.getEmail();
    String temppass=cust.getPassword();
    Customer obj=null;
    if(tempemail !=null && temppass!=null) {
    obj=service.fetchstdbyemailandpass(tempemail, temppass);
 
    }
    if(obj ==null)
    {
    throw new Exception("User doesnot exits");
    }
    return obj;
 
    }
	

}
